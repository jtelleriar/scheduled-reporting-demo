## test output generation from templates

library(oaStyle)
library(rmarkdown)

# slides
rmarkdown::render(createSlides(tempfile(fileext = ".Rmd")))

# report
rmarkdown::render(createReport(tempfile(fileext = ".Rmd")))


# Tests using unified Rmd file for html and pdf

# Html Report
rmarkdown::render(createReport(filename = tempfile(fileext = ".Rmd")), 
    output_format = 'oaStyle::html_report')

# Pdf Report
rmarkdown::render(createReport(filename = tempfile(fileext = ".Rmd")), 
    output_format = 'oaStyle::pdf_report')
