oaRed <- "#e52323"
oaBlue <- "#32a6d3"
oaGray <- oaGrey <- "#e6e6e6"

#' Use colors from OA logo
#' 
#' @param which which color(s) to return, a combination of "red", "blue" and 
#' "grey"/"gray" 
#' @return character vector with colors to be used in plotting 
#' @examples
#' oaColor(c("red", "blue", "grey"))
#' oaColor()  # same as above
#' oaColor("blue")
#' plot(rnorm(100), pch = 19, col = oaColor())
#' @author Maxim Nazarov
#' @export
oaColor <- function(which = c("red", "blue", "grey")) {
  which[which == "gray"] <- "grey"
  which <- match.arg(which, several.ok = TRUE)
 
  unname(c("red" = oaRed, "blue" = oaBlue, "grey" = oaGrey)[which])
}