#' OA logo
#' 
#' @param text Whether to return logo with company name (if TRUE) or only the 
#' logo (if FALSE, default).
#' @param format Logo file format to return (currently either "png" or "svg").
#' @return path to OA logo
#' @examples
#' oaLogo()
#' oaLogo(text = TRUE, format = "svg")
#' oaLogo("svg")  # undocumented feature 
#' @author Maxim Nazarov
#' @export
oaLogo <- function(text = FALSE, format = c("png", "svg")) {

  # allow also oaLogo("svg")
  if (text %in% c("png", "svg"))
    format <- text
  
  format <- match.arg(format)
  
  system.file("images", paste0("logo", if (isTRUE(text)) "Text", ".", format), 
      package = "oaStyle")
}