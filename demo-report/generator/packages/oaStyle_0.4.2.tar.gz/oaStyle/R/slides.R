ioslidesFilter <- function() {
  system.file("filters", "ioslides.lua", package = "oaStyle")  
}

ioslidesCss <- function() {
  system.file("css", "ioslides.css", package = "oaStyle")
}

#' OA-themed 'ioslides' presentation
#' 
#' @description Wrapper around \code{\link[rmarkdown]{ioslides_presentation}} 
#' format that includes custom logo, styles and slide counter (red line on top).
#' To be used as output format for \code{rmarkdown} files: 
#' \verb{
#' ---
#' output: oaStyle::ioslides
#' ---
#' } or 
#' \verb{
#' ---
#' output: 
#'   oaStyle::ioslides:
#'     smaller: false
#' ---
#' }
#' 
#' @param widescreen Display presentation with wider dimensions (deafult is TRUE).
#' @param smaller Use smaller text size (default is TRUE).
#' @param logo Logo file path. By default OA logo is used.
#' @param css Extra CSS file(s) to use in addition to OA default style.
#' @param usePageNumbers Whether to use default slide numbers instead of 
#' the running red line on top (default is FALSE).
#' @param pandoc_args Additional command line options to pass to pandoc.
#' @param ... Further arguments passed to 
#' \code{\link[rmarkdown]{ioslides_presentation}}.
#' @return R Markdown output format to pass to \code{\link[rmarkdown]{render}}.
#' @seealso \code{\link[rmarkdown]{ioslides_presentation}} for further arguments,
#' \code{\link{html_report}} for reports.
#' @author Maxim Nazarov
#' @importFrom rmarkdown pandoc_available ioslides_presentation
#' @export
ioslides <- function(widescreen = TRUE, smaller = TRUE, 
    logo = oaLogo(), css = NULL, usePageNumbers = FALSE, pandoc_args = NULL, 
    ...) {
  
  # add default CSS
  css <- c(ioslidesCss(), css)
  
  custom_pandoc_args <- NULL
  
  if (!usePageNumbers) {
    # lua filters require pandoc >= 2.0 (but avoid versions 2.0.4 and 2.0.5 
    # that have regression bug related to lua-filters)
    if (rmarkdown::pandoc_available("2.0")) {
      if (rmarkdown::pandoc_version() %in% as.numeric_version(c("2.0.4", "2.0.5"))) {
        warning("Red bar on top doesn't work with pandoc 2.0.4 and 2.0.5,", 
            " falling back to default slide numbers")  
      } else {
        custom_pandoc_args <- c("--lua-filter", ioslidesFilter())
      }
    } else 
      warning("Red bar on top requires pandoc >= 2.0, falling back to default slide numbers")
  }
  
  # if pandoc_args are specified, keep them
  if (!is.null(pandoc_args))
    custom_pandoc_args <- c(pandoc_args, custom_pandoc_args)  
  
  rmarkdown::ioslides_presentation(logo = logo, widescreen = widescreen,
      smaller = smaller, css = css, pandoc_args = custom_pandoc_args, ...)
  
}

#' Create presentation template
#' 
#' @param filename File path where presentation should be created (defaults 
#' to "presentation.Rmd" in the current working directory).
#' @param overwrite Whether to overwrite existing file with the same name. 
#' @return \code{filename} invisibly or NULL if failed.
#' 
#' @export
createSlides <- function(filename = "presentation.Rmd", overwrite = FALSE) {
  
  if (!grepl("\\.Rmd$", filename))
    filename <- paste0(filename, ".Rmd")
  
  success <- file.copy(
      from = system.file("templates", "presentation.Rmd", package = "oaStyle"), 
      to = filename, 
      overwrite = overwrite
  )
  
  if (success) {
    message("Presentation template created at ", filename)
    invisible(filename)
  } else {
    message("Template not created, please use different name, or set overwrite = TRUE")
    invisible(NULL)
  }
  
}
