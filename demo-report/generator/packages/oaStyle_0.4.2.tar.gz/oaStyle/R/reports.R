reportCss <- function() {
  system.file("css", "reports.css", package = "oaStyle")
}

#' OA-themed HTML report
#' 
#' @description Wrapper around \code{\link[rmarkdown]{html_document}} format that 
#' includes custom logo and styles. 
#' To be used as output format for \code{rmarkdown} files: 
#' \verb{
#' ---
#' output: oaStyle::html_report
#' ---
#' } or with options
#' \verb{
#' ---
#' output: 
#'   oaStyle::html_report:
#'     number_sections: false
#' ---
#' }
#' 
#' @inheritParams ioslides
#' @param secondLogo Path to the optional second logo to be added to the right 
#' side of the report header. Use \code{secondLogoStyle} argument to adjust the 
#' view.
#' @param toc Whether to include a table of contents in the output (default 
#' is TRUE).
#' @param toc_depth Depth of headers to include in table of contents (default 
#' is 5).
#' @param toc_float Parameters for the floating TOC, by default it is on and 
#' collapsed.
#' @param number_sections Whether to number section headings (default is TRUE).
#' @param includes Named list of additional content to include within the 
#' document.
#' @param bookdown Whether to use \code{\link[bookdown]{html_document2}} 
#' instead of \code{\link[rmarkdown]{html_document}} as a base format. This 
#' adds the capability of numbering figures/tables/equations/theorems and 
#' cross-referencing them.
#' @param secondLogoStyle Optional inline CSS style to be used for the 
#' \code{secondLogo}. The default height is the same as used for the main 
#' \code{logo}, you can use e.g. "height: unset;" to not scale the image. 
#' Alternatively the style can be adapted via \code{css}.
#' @param ... Further arguments passed to 
#' \code{\link[rmarkdown]{html_document}}.
#' @return R Markdown output format to pass to \code{\link[rmarkdown]{render}}.
#' @seealso \code{\link[rmarkdown]{html_document}} for further arguments, 
#' \code{\link[bookdown]{html_document2}} for details of extra \code{bookdown} 
#' features, \code{\link{ioslides}} for presentations. 
#' @author Maxim Nazarov
#' @importFrom rmarkdown html_document
#' @importFrom bookdown html_document2
#' @export
html_report <- function(logo = oaLogo(), secondLogo = NULL, css = NULL, 
    toc = TRUE, toc_depth = 5, toc_float = list("collapsed" = TRUE), 
    number_sections = TRUE, includes = NULL, bookdown = TRUE, 
    secondLogoStyle = NULL, ...) {
  
  # prepare logo html
  logoText <- ""
  if (!is.null(logo)) {
    if (file.exists(logo)) {
      logoText <- c(logoText, '<div class = "logo"><img src="', logo, '"></div>')
    } else {
      warning("Logo not found at ", path.expand(logo))
    }
  }
    
  if (!is.null(secondLogo)) {
    if (file.exists(secondLogo)) {
      logoText <- c(logoText, '<div class = "logo2"><img src="', secondLogo, 
          '" style="', secondLogoStyle, '"></div>')
    } else {
      warning("Logo not found at ", path.expand(secondLogo))
    }
  }
  
  if (length(logoText)) {
    logoHtml <- tempfile(fileext = ".html")
    cat(logoText, sep = "", file = logoHtml)

    if (!is.null(includes))
      includes$before_body <- c(includes$before_body, logoHtml) 
    else {
      includes <- list()
      includes$before_body <- logoHtml
    }
  }
  # add default CSS
  css <- c(reportCss(), css)
  
  FUN <- if (isTRUE(bookdown)) bookdown::html_document2 else rmarkdown::html_document 

  FUN(css = css, toc = toc, toc_depth = toc_depth, 
      toc_float = toc_float, number_sections = number_sections,  
      includes = includes, ...)

}

#' Create report template
#' 
#' @param filename File path where presentation should be created (defaults 
#' to "report.Rmd" in the current working directory).
#' @param overwrite Whether to overwrite existing file with the same name. 
#' @return \code{filename} invisibly or NULL if failed.
#' 
#' @export
createReport <- function(filename = "report.Rmd", overwrite = FALSE) {
  
  if (!grepl("\\.Rmd$", filename))
    filename <- paste0(filename, ".Rmd")
  
  success <- file.copy(
      from = system.file("templates", "report.Rmd", package = "oaStyle"), 
      to = filename, 
      overwrite = overwrite
  )
  
  if (success) {
    message("Report template created at ", filename)
    invisible(filename)
  } else {
    message("Template not created, please use different name, or set overwrite = TRUE")
    invisible(NULL)
  }
  
}



#' OA-themed PDF report
#' 
#' @description Wrapper around \code{\link[rmarkdown]{pdf_document}} format that 
#' includes custom logo and styles. 
#' To be used as output format for \code{rmarkdown} files: 
#' \verb{
#' ---
#' output: 
#'   oaStyle::pdf_report
#' ---
#' } or 
#' \verb{
#' ---
#' output: 
#'   oaStyle::pdf_report:
#'     number_sections: false
#'     latex_engine: lualatex
#' ---
#' }
#' 
#' @param logo path to logo image
#' @param toc Whether to include a table of contents in the output (default 
#' is TRUE).
#' @param toc_depth Depth of headers to include in table of contents (default 
#' is 5).
#' @param number_sections Whether to number section headings (default is TRUE).
#' @param includes Named list of additional content to include within the 
#' document.
#' @param bookdown Whether to use \code{\link[bookdown]{pdf_document2}} 
#' instead of \code{\link[rmarkdown]{pdf_document}} as a base format. This 
#' adds the capability of numbering figures/tables/equations/theorems and 
#' cross-referencing them.  
#' @param latex_engine string specifying the engine used to render pdf documents 
#' (default is 'xelatex')
#' @param template path to tex template used to generate the pdf document
#' @param linkcolor string indicating the color for internal links
#' @param urlcolor string indicating the color for external links
#' @param mainfont string specifying the document font
#' @param logoSize string indicating the logo width (default is 1.2cm)
#' @param bigLogo path to logo to be included in the middle of the titlepage
#' @param bigLogoSize Width of bigLogo (default is 4cm)
#' @param rheadLogo Whether to show the logo in page headers (default is FALSE)
#' @param ... Further arguments passed to 
#' \code{\link[rmarkdown]{pdf_document}}.
#' @return R Markdown output format to pass to \code{\link[rmarkdown]{render}}.
#' @seealso \code{\link[rmarkdown]{pdf_document}} for further arguments, 
#' \code{\link[bookdown]{pdf_document2}} for details of extra \code{bookdown} 
#' features.
#' @importFrom rmarkdown pdf_document
#' @importFrom bookdown pdf_document2 
#' @export
pdf_report <- function(logo = oaLogo(), toc = TRUE, toc_depth = 5, 
    number_sections = TRUE, includes = NULL, bookdown = TRUE, latex_engine = "xelatex", 
    template = NULL, linkcolor = "oaRed", 
    urlcolor = "oaRed", mainfont = "Cantarell", logoSize, bigLogo, bigLogoSize,
    rheadLogo, ...) {
  
  # Use default latex template
  if (is.null(template))
    template <- system.file("templates", "default.tex", package = "oaStyle")
  
  
  # Include tex file containing color definitions
  headerTemplate <- system.file("templates", "header.tex", package = "oaStyle")
  if (is.null(includes)) {
    includes <- list()
    includes$in_header <- headerTemplate
  } else {
    includes$in_header <- c(headerTemplate, includes$in_header)
  }
  
  # Set the template variables
  pandoc_args <- c("--variable", paste0("logo=", logo), 
                   "--variable", paste0("linkcolor=", linkcolor),
                   "--variable", paste0("urlcolor=", linkcolor),
                   "--variable", paste0("mainfont=", mainfont))
  if (!missing(logoSize)){
    pandoc_args <- c(pandoc_args, "--variable", paste0("logoSize=", logoSize))
  }
  if (!missing(bigLogo)){
    pandoc_args <- c(pandoc_args, "--variable", paste0("bigLogo=", bigLogo))
  }
  if (!missing(bigLogoSize)){
    pandoc_args <- c(pandoc_args, "--variable", paste0("bigLogoSize=", bigLogoSize))
  }
  if (!missing(rheadLogo)){
    pandoc_args <- c(pandoc_args, "--variable", paste0("rheadLogo=", rheadLogo))
  }
               
  FUN <- if (isTRUE(bookdown)) bookdown::pdf_document2  else rmarkdown::pdf_document 
  
  FUN(toc = toc, toc_depth = toc_depth, number_sections = number_sections,  
      includes = includes, latex_engine = latex_engine, template = template,
      pandoc_args = pandoc_args,...)
  
}
