#' Open Analytics Style and Themes
#' 
#' @description \code{oaStyle} provides functions useful for creation of 
#' presentations and reports with consistent style, using Open Analytics logo, 
#' colors and fonts.
#'
#' @details The following components are available:
#' \enumerate{
#'   \item \code{\link{oaLogo}}, logo with and without company name 
#'   \item \code{\link{oaColor}}, colors from the logo
#'   \item \code{rmarkdown} output formats for slides (\code{\link{ioslides}}) 
#' and reports (\code{\link{html_report}}, \code{\link{pdf_report}})
#'   \item functions to create presentation/report templates: 
#' \code{\link{createSlides}} and \code{\link{createReport}}
#' }
#'  
#' @docType package
#' @name oaStyle

NULL

#' @importFrom utils packageVersion
.onAttach <- function(libname, pkgname) {
  if (interactive()) {
    packageStartupMessage("oaStyle, version ", packageVersion("oaStyle"), ", run ?oaStyle to get started")
  }
}