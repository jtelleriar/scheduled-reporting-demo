#!/usr/bin/env Rscript

cont <- paste0(readLines('stdin', encoding = "UTF-8", warn = FALSE))
contents <- jsonlite::fromJSON(cont, simplifyVector = FALSE)

slideLevel <- 2 
## assume defualt, code below for a general solution, 
## but it is not really used:
#if ("slide_level" %in% names(contents$meta$output$c[[1]]$c))
#  slideLevel <- as.numeric(contents$meta$output$c[[1]]$c[["slide_level"]]$c)

# get numebr of slides
nSlides <- 1
for (iRow in seq_along(contents$blocks)) {
  if (contents$blocks[[iRow]]$t == "Header" && contents$blocks[[iRow]]$c[[1]] <= slideLevel || contents$blocks[[iRow]]$t == "HorizontalRule") {
    nSlides <- nSlides+1
  }
}

# generate a style block with growing red line on top instead of slide numbers
styleHtml <- "<style>"
for(i in 2:nSlides) {
  styleHtml <- paste0(styleHtml, "\nslide[data-slide-num='", i, "']::after {
          content: '\\00a0' !important; 
          background: rgb(229, 35, 35) !important; 
          line-height: 0.4 !important; 
          position: absolute !important;
          left: 0 !important; 
          bottom: unset !important;
          top: 0 !important; 
          right: unset !important;
          width: ", ((i-1)/(nSlides-1))*100, "% !important;}\n")
}
styleHtml <- paste0(styleHtml, "</style>")
styleBlock <- list(list(t = "RawBlock", c = list("html", styleHtml)))

# insert it in the document
contents$blocks <- append(contents$blocks, styleBlock, after = 0)

res <- jsonlite::toJSON(contents, auto_unbox = TRUE, digits = NA)

write(res, stdout())
closeAllConnections()