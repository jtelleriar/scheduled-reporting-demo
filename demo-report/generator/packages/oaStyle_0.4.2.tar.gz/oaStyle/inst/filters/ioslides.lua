-- count headers of level 1 and 2 and horizontal rules to get number of slides
slides = 1  -- title slide is always there
function Block(el)
  if (el.t == "Header" and el.level <= 2) or (el.t == "HorizontalRule") then
    slides = slides + 1
  end
end

function Pandoc(doc)
  -- generate css with running red line on top instead of slide numbers
  local text = ""
  for i = 2, slides do   -- (except 1st slide)
    text = text .. "\nslide[data-slide-num='" .. i .. [[']::after {
      content: '\00a0' !important; 
      background: rgb(229, 35, 35) !important; 
      line-height: 0.4 !important; 
      position: absolute !important;
      left: 0 !important; 
      bottom: unset !important;
      top: 0 !important; 
      right: unset !important;
      width: ]] .. ((i-1)/(slides-1))*100 .. "% !important;\n}\n"
  end
  -- make a style element with the above css
  htmlBlock = pandoc.RawBlock("html", "<style>" .. text .. "</style>")
  -- insert in the document before everything else
  table.insert(doc.blocks, 1, htmlBlock)
  return pandoc.Pandoc(doc.blocks, doc.meta)
end
